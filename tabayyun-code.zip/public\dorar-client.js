// TABAYYUN — Hadith verification access layer.
//
// Scientific content source: Dorar Al-Sunniyyah.
// Technical access: Al-Bahith Al-Hadithi API (search.sunnah.one).
//
// This endpoint supports CORS and returns hadith search results
// including text, ruling (hukm), takhreej, muhaddith and source.
//
// No fallback to the six books or any unrelated hadith database.

const SEARCH_ENDPOINT = 'https://search.sunnah.one/';
const REQUEST_TIMEOUT = 15000;

/**
 * Remove HTML highlighting returned by the search API.
 * Example:
 *   "<mark>السلام</mark>" -> "السلام"
 */
function stripHtml(value) {
  return String(value ?? '')
    .replace(/<mark[^>]*>/gi, '')
    .replace(/<\/mark>/gi, '')
    .replace(/<[^>]+>/g, '')
    .trim();
}

/**
 * Convert a result from Al-Bahith Al-Hadithi API
 * to the structure expected by TABAYYUN's existing pipeline.
 *
 * We deliberately keep several aliases because the current
 * classification/matching code may read either Arabic-source
 * field names or the normalized English names.
 */
function normalizeResult(item) {
  const text = stripHtml(item?.text);
  const hukm = stripHtml(item?.hukm);
  const takhreej = stripHtml(item?.takhreej);

  const rawy = item?.rawy ?? '';
  const muhaddith = item?.muhaddith ?? '';
  const source = item?.source ?? '';
  const sourceLocation = item?.source_location ?? '';

  return {
    // Main normalized fields
    text,
    hadith: text,
    hukm,
    grade: hukm,
    ruling: hukm,

    rawy,
    narrator: rawy,

    muhaddith,
    scholar: muhaddith,

    source,
    source_location: sourceLocation,

    takhreej,

    // Keep useful fields returned by the API.
    sharh_id: item?.sharh_id ?? null,
    sharh_other: item?.sharh_other ?? false,

    // Metadata for TABAYYUN.
    provider: 'الباحث الحديثي',
    contentSource: 'الدرر السنية',

    // Preserve the original object in case another part
    // of the current pipeline needs one of its fields.
    raw: item,
  };
}

/**
 * Search Dorar content through Al-Bahith Al-Hadithi API.
 */
async function searchHadith(query) {
  const cleanQuery = String(query || '').trim();

  if (!cleanQuery) {
    return [];
  }

  const controller = new AbortController();

  const timer = setTimeout(() => {
    controller.abort();
  }, REQUEST_TIMEOUT);

  try {
    const params = new URLSearchParams({
      cors: '1',
      q: cleanQuery,
    });

    const response = await fetch(
      `${SEARCH_ENDPOINT}?${params.toString()}`,
      {
        method: 'GET',
        headers: {
          Accept: 'application/json',
        },
        signal: controller.signal,
      }
    );

    if (!response.ok) {
      throw new Error(
        `Hadith search API HTTP ${response.status}`
      );
    }

    const payload = await response.json();

    if (!payload || !Array.isArray(payload.data)) {
      throw new Error(
        'Hadith search API returned an unexpected response'
      );
    }

    console.info(
      `Hadith search connection: search.sunnah.one (${payload.data.length} results)`
    );

    return payload.data
      .map(normalizeResult)
      .filter((item) => item.text);
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error(
        'انتهت مهلة الاتصال بالباحث الحديثي.'
      );
    }

    console.error(
      'Hadith search API unreachable:',
      error
    );

    throw new Error(
      `تعذر الوصول إلى الباحث الحديثي: ${
        error?.message || String(error)
      }`
    );
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Kept for compatibility with the current pipeline.
 */
export const activeRoute = () => 'hadith-search-api';

/**
 * This is the function currently imported by pipeline.js.
 */
export async function searchFromBrowser(query) {
  return searchHadith(query);
}